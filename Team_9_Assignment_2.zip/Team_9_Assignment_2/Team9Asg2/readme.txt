
1) Unzip the Team_9_Assignment_2  into a directory.

2) To make dbCode class available as library Start IJ and open the project SangavaramMasg1.

3) Build the project.

4) Open dbCode class in Inventorydblib module.

5) In IntelliJ open maven which appears on right side open Inventorydblib> Lifecycle > install

6) Now DB library should be available. 

7) Open Team9Asg2 in IntelliJ.

8) To make sure artifact is updated. Go to File > project structure. Under Project Setting go to artifacts in to go to Team9Asg2: War exploded and make sure include in project build is selected.

9) On top right click on glassfish > edit configuration. Under glassfish 7.0.13 go to deployment and make sure it is under deploy at server startup has Team9Asg2: War exploded.

10) Run the project using glassfish. A browser window should open with web application with two buttons.

11) Clicking on Employee Assignment List takes to a page where you need employee id in text field. After giving employee id it shows employee name and a list of equipment along with other details.

12) Clicking on Assigning Computer/Reassigning Computer takes a page with 3 text boxes and 3 buttons after filling correct data in these boxes you  choose assign computer or reassign computer according to need.

13) Main menu on all pages takes to the first page.

